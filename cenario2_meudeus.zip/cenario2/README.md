# Cenário 2 – Sistema de Oficina Mecânica

## Tabelas Identificadas

### cliente
```sql
CREATE TABLE cliente (
    id       SERIAL PRIMARY KEY,
    nome     VARCHAR(100) NOT NULL,
    telefone VARCHAR(20)  NOT NULL
);
```

### veiculo
```sql
CREATE TABLE veiculo (
    id         SERIAL PRIMARY KEY,
    placa      VARCHAR(10)  NOT NULL UNIQUE,
    modelo     VARCHAR(100) NOT NULL,
    ano        INTEGER      NOT NULL,
    id_cliente INTEGER      NOT NULL REFERENCES cliente(id)
);
```

### ordem_servico
```sql
CREATE TABLE ordem_servico (
    id         SERIAL PRIMARY KEY,
    id_veiculo INTEGER        NOT NULL REFERENCES veiculo(id),
    descricao  TEXT           NOT NULL,
    valor      NUMERIC(10, 2) NOT NULL,
    status     VARCHAR(20)    NOT NULL DEFAULT 'ABERTA'
);
```

---

## Regras de Negócio

| # | Regra |
|---|-------|
| RN01 | Não é permitido abrir uma ordem de serviço para um veículo que não esteja cadastrado. |
| RN02 | O valor do serviço não pode ser negativo. |
| RN03 | Um cliente pode ter mais de um veículo cadastrado. |
| RN04 | Ao abrir uma ordem de serviço, o status inicial é sempre "ABERTA". |
| RN05 | Uma ordem de serviço pode ser marcada como "CONCLUIDA". |
| RN06 | É possível consultar todo o histórico de manutenções de um determinado veículo. |

---

## Fluxo simulado na Main

`Cliente → Veículo → Ordem de Serviço`

1. Cadastra um cliente
2. Cadastra um veículo vinculado ao cliente
3. Lista os veículos do cliente
4. Abre uma ordem de serviço para o veículo (movimento)
5. Exibe o histórico de manutenções do veículo
6. Tenta abrir ordem com valor negativo (demonstra RN02)
