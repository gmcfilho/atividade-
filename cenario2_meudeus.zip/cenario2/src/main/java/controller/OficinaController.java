package controller;

import model.Cliente;
import model.OrdemServico;
import model.Veiculo;
import service.ClienteService;
import service.OrdemServicoService;

import java.sql.SQLException;
import java.util.List;

public class OficinaController {

    private final ClienteService clienteService;
    private final OrdemServicoService ordemServicoService;

    public OficinaController(ClienteService clienteService, OrdemServicoService ordemServicoService) {
        this.clienteService = clienteService;
        this.ordemServicoService = ordemServicoService;
    }

    public Cliente cadastrarCliente(Cliente cliente) {
        try {
            Cliente salvo = clienteService.cadastrar(cliente);
            System.out.println("[SUCESSO] Cliente cadastrado: " + salvo);
            return salvo;
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
            return null;
        }
    }

    public Veiculo cadastrarVeiculo(Veiculo veiculo) {
        try {
            Veiculo salvo = clienteService.cadastrarVeiculo(veiculo);
            System.out.println("[SUCESSO] Veículo cadastrado: " + salvo);
            return salvo;
        } catch (IllegalArgumentException e) {
            System.out.println("[ERRO DE NEGÓCIO] " + e.getMessage());
            return null;
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
            return null;
        }
    }

    public OrdemServico abrirOrdemServico(OrdemServico os) {
        try {
            OrdemServico salva = ordemServicoService.abrir(os);
            System.out.println("[SUCESSO] Ordem de serviço aberta: " + salva);
            return salva;
        } catch (IllegalArgumentException e) {
            System.out.println("[ERRO DE NEGÓCIO] " + e.getMessage());
            return null;
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
            return null;
        }
    }

    public void listarHistoricoVeiculo(Long idVeiculo) {
        try {
            List<OrdemServico> lista = ordemServicoService.listarPorVeiculo(idVeiculo);
            System.out.println("[HISTÓRICO] Ordens de serviço do veículo id=" + idVeiculo + ":");
            lista.forEach(os -> System.out.println("  " + os));
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
        }
    }

    public void listarVeiculosDoCliente(Long idCliente) {
        try {
            List<Veiculo> veiculos = clienteService.listarVeiculosDoCliente(idCliente);
            System.out.println("[VEÍCULOS] do cliente id=" + idCliente + ":");
            veiculos.forEach(v -> System.out.println("  " + v));
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
        }
    }
}
