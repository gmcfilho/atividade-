import controller.OficinaController;
import model.Cliente;
import model.OrdemServico;
import model.Veiculo;
import repository.ClienteRepository;
import repository.OrdemServicoRepository;
import repository.VeiculoRepository;
import service.ClienteService;
import service.OrdemServicoService;

import java.math.BigDecimal;

public class Main {

    public static void main(String[] args) {
        ClienteRepository clienteRepository = new ClienteRepository();
        VeiculoRepository veiculoRepository = new VeiculoRepository();
        OrdemServicoRepository ordemServicoRepository = new OrdemServicoRepository();

        ClienteService clienteService = new ClienteService(clienteRepository, veiculoRepository);
        OrdemServicoService ordemServicoService = new OrdemServicoService(ordemServicoRepository, veiculoRepository);

        OficinaController controller = new OficinaController(clienteService, ordemServicoService);

        System.out.println("=== SIMULAÇÃO: OFICINA MECÂNICA ===\n");

        System.out.println("--- 1. Cadastrando cliente ---");
        Cliente cliente = controller.cadastrarCliente(new Cliente("João Pereira", "44999880002"));

        if (cliente == null) return;

        System.out.println("\n--- 2. Cadastrando veículo ---");
        Veiculo veiculo = controller.cadastrarVeiculo(new Veiculo("ABC-1234", "Honda Civic", 2020, cliente.getId()));

        if (veiculo == null) return;

        System.out.println("\n--- 3. Veículos do cliente ---");
        controller.listarVeiculosDoCliente(cliente.getId());

        System.out.println("\n--- 4. Abrindo ordem de serviço (movimento) ---");
        OrdemServico os = controller.abrirOrdemServico(
            new OrdemServico(veiculo.getId(), "Troca de óleo e revisão geral", new BigDecimal("380.00"), "ABERTA")
        );

        System.out.println("\n--- 5. Histórico de manutenções do veículo ---");
        controller.listarHistoricoVeiculo(veiculo.getId());

        System.out.println("\n--- 6. Tentativa com valor negativo (deve falhar) ---");
        controller.abrirOrdemServico(
            new OrdemServico(veiculo.getId(), "Alinhamento", new BigDecimal("-100.00"), "ABERTA")
        );

        System.out.println("\n=== FIM DA SIMULAÇÃO ===");
    }
}
