package service;

import model.OrdemServico;
import model.Veiculo;
import repository.OrdemServicoRepository;
import repository.VeiculoRepository;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class OrdemServicoService {

    private final OrdemServicoRepository ordemServicoRepository;
    private final VeiculoRepository veiculoRepository;

    public OrdemServicoService(OrdemServicoRepository ordemServicoRepository, VeiculoRepository veiculoRepository) {
        this.ordemServicoRepository = ordemServicoRepository;
        this.veiculoRepository = veiculoRepository;
    }

    public OrdemServico abrir(OrdemServico os) throws SQLException {
        Optional<Veiculo> veiculo = veiculoRepository.buscarPorId(os.getIdVeiculo());
        if (veiculo.isEmpty()) {
            throw new IllegalArgumentException("Veículo com id " + os.getIdVeiculo() + " não encontrado.");
        }

        if (os.getValor().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("O valor do serviço não pode ser negativo.");
        }

        os.setStatus("ABERTA");
        return ordemServicoRepository.salvar(os);
    }

    public void concluir(Long idOrdem) throws SQLException {
        Optional<OrdemServico> os = ordemServicoRepository.buscarPorId(idOrdem);
        if (os.isEmpty()) {
            throw new IllegalArgumentException("Ordem de serviço id " + idOrdem + " não encontrada.");
        }
        OrdemServico ordem = os.get();
        ordem.setStatus("CONCLUIDA");
        ordemServicoRepository.atualizar(ordem);
    }

    public List<OrdemServico> listarPorVeiculo(Long idVeiculo) throws SQLException {
        return ordemServicoRepository.listarPorVeiculo(idVeiculo);
    }

    public List<OrdemServico> listarTodas() throws SQLException {
        return ordemServicoRepository.listarTodas();
    }
}
