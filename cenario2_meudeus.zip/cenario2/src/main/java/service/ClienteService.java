package service;

import model.Cliente;
import model.Veiculo;
import repository.ClienteRepository;
import repository.VeiculoRepository;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class ClienteService {

    private final ClienteRepository clienteRepository;
    private final VeiculoRepository veiculoRepository;

    public ClienteService(ClienteRepository clienteRepository, VeiculoRepository veiculoRepository) {
        this.clienteRepository = clienteRepository;
        this.veiculoRepository = veiculoRepository;
    }

    public Cliente cadastrar(Cliente cliente) throws SQLException {
        return clienteRepository.salvar(cliente);
    }

    public Veiculo cadastrarVeiculo(Veiculo veiculo) throws SQLException {
        Optional<Cliente> cliente = clienteRepository.buscarPorId(veiculo.getIdCliente());
        if (cliente.isEmpty()) {
            throw new IllegalArgumentException("Cliente com id " + veiculo.getIdCliente() + " não encontrado.");
        }
        return veiculoRepository.salvar(veiculo);
    }

    public List<Veiculo> listarVeiculosDoCliente(Long idCliente) throws SQLException {
        return veiculoRepository.listarPorCliente(idCliente);
    }

    public List<Cliente> listarTodos() throws SQLException {
        return clienteRepository.listarTodos();
    }
}
