package model;

import java.math.BigDecimal;

public class OrdemServico {
    private Long id;
    private Long idVeiculo;
    private String descricao;
    private BigDecimal valor;
    private String status;

    public OrdemServico() {}

    public OrdemServico(Long id, Long idVeiculo, String descricao, BigDecimal valor, String status) {
        this.id = id;
        this.idVeiculo = idVeiculo;
        this.descricao = descricao;
        this.valor = valor;
        this.status = status;
    }

    public OrdemServico(Long idVeiculo, String descricao, BigDecimal valor, String status) {
        this.idVeiculo = idVeiculo;
        this.descricao = descricao;
        this.valor = valor;
        this.status = status;
    }

    public Long getId() { return id; }
    public Long getIdVeiculo() { return idVeiculo; }
    public String getDescricao() { return descricao; }
    public BigDecimal getValor() { return valor; }
    public String getStatus() { return status; }
    public void setId(Long id) { this.id = id; }
    public void setIdVeiculo(Long idVeiculo) { this.idVeiculo = idVeiculo; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "OrdemServico{id=" + id + ", idVeiculo=" + idVeiculo + ", descricao='" + descricao + "', valor=" + valor + ", status='" + status + "'}";
    }
}
