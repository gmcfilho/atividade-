package repository;

import model.OrdemServico;
import util.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class OrdemServicoRepository {

    public OrdemServico salvar(OrdemServico os) throws SQLException {
        String sql = "INSERT INTO ordem_servico (id_veiculo, descricao, valor, status) VALUES (?, ?, ?, ?) RETURNING id";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, os.getIdVeiculo());
            stmt.setString(2, os.getDescricao());
            stmt.setBigDecimal(3, os.getValor());
            stmt.setString(4, os.getStatus());
            ResultSet rs = stmt.executeQuery();
            rs.next();
            return new OrdemServico(rs.getLong("id"), os.getIdVeiculo(), os.getDescricao(), os.getValor(), os.getStatus());
        }
    }

    public Optional<OrdemServico> buscarPorId(Long id) throws SQLException {
        String sql = "SELECT * FROM ordem_servico WHERE id = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, id);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? Optional.of(mapear(rs)) : Optional.empty();
        }
    }

    public List<OrdemServico> listarTodas() throws SQLException {
        String sql = "SELECT * FROM ordem_servico ORDER BY id DESC";
        List<OrdemServico> lista = new ArrayList<>();
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public List<OrdemServico> listarPorVeiculo(Long idVeiculo) throws SQLException {
        String sql = "SELECT * FROM ordem_servico WHERE id_veiculo = ? ORDER BY id DESC";
        List<OrdemServico> lista = new ArrayList<>();
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, idVeiculo);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public void atualizar(OrdemServico os) throws SQLException {
        String sql = "UPDATE ordem_servico SET id_veiculo = ?, descricao = ?, valor = ?, status = ? WHERE id = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, os.getIdVeiculo());
            stmt.setString(2, os.getDescricao());
            stmt.setBigDecimal(3, os.getValor());
            stmt.setString(4, os.getStatus());
            stmt.setLong(5, os.getId());
            stmt.executeUpdate();
        }
    }

    public void deletar(Long id) throws SQLException {
        String sql = "DELETE FROM ordem_servico WHERE id = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, id);
            stmt.executeUpdate();
        }
    }

    private OrdemServico mapear(ResultSet rs) throws SQLException {
        return new OrdemServico(
            rs.getLong("id"),
            rs.getLong("id_veiculo"),
            rs.getString("descricao"),
            rs.getBigDecimal("valor"),
            rs.getString("status")
        );
    }
}
