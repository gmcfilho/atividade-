# Cenário 1 – Sistema de Clínica Veterinária

## Tabelas Identificadas

### Tutor
```sql
CREATE TABLE tutor (
    id       SERIAL PRIMARY KEY,
    nome     VARCHAR(100) NOT NULL,
    endereco VARCHAR(200) NOT NULL,
    telefone VARCHAR(20)  NOT NULL
);
```

### Animal
```sql
CREATE TABLE animal (
    id       SERIAL PRIMARY KEY,
    nome     VARCHAR(100) NOT NULL,
    especie  VARCHAR(50)  NOT NULL,
    raca     VARCHAR(50)  NOT NULL,
    id_tutor INTEGER NOT NULL REFERENCES tutor(id)
);
```

### Consulta
```sql
CREATE TABLE consulta (
    id        SERIAL PRIMARY KEY,
    id_animal INTEGER        NOT NULL REFERENCES animal(id),
    data      DATE           NOT NULL,
    motivo    TEXT           NOT NULL,
    valor     NUMERIC(10, 2) NOT NULL
);
```

---

## Regras de Negócio

| # | Regra |
|---|-------|
| RN01 | Não é permitido registrar uma consulta para um animal que não esteja cadastrado no sistema. |
| RN02 | O valor da consulta não pode ser negativo. |
| RN03 | Um tutor pode ter mais de um animal cadastrado. |
| RN04 | Um animal pertence a um único tutor (chave estrangeira obrigatória). |
| RN05 | É possível consultar todo o histórico de atendimentos de um animal específico. |
| RN06 | É possível listar todos os animais de um determinado tutor. |

---

## Fluxo simulado na Main

`Tutor → Animal → Consulta`

1. Cadastra um tutor
2. Cadastra um animal vinculado ao tutor
3. Lista os animais do tutor
4. Registra uma consulta para o animal (movimento)
5. Exibe o histórico de consultas do animal
6. Tenta registrar consulta com valor negativo (demonstra RN02)
