import controller.ConsultaController;
import model.Animal;
import model.Consulta;
import model.Tutor;
import repository.AnimalRepository;
import repository.ConsultaRepository;
import repository.TutorRepository;
import service.AnimalService;
import service.ConsultaService;
import service.TutorService;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {
        TutorRepository tutorRepository = new TutorRepository();
        AnimalRepository animalRepository = new AnimalRepository();
        ConsultaRepository consultaRepository = new ConsultaRepository();

        TutorService tutorService = new TutorService(tutorRepository, animalRepository);
        AnimalService animalService = new AnimalService(animalRepository, tutorRepository);
        ConsultaService consultaService = new ConsultaService(consultaRepository, animalRepository);

        ConsultaController controller = new ConsultaController(consultaService, tutorService, animalService);

        System.out.println("=== SIMULAÇÃO: CLÍNICA VETERINÁRIA ===\n");

        System.out.println("--- 1. Cadastrando tutor ---");
        Tutor tutor = controller.cadastrarTutor(new Tutor("Maria Silva", "Rua das Flores, 123", "44999990001"));

        if (tutor == null) return;

        System.out.println("\n--- 2. Cadastrando animal do tutor ---");
        Animal animal = controller.cadastrarAnimal(new Animal("Rex", "Cachorro", "Labrador", tutor.getId()));

        if (animal == null) return;

        System.out.println("\n--- 3. Animais cadastrados para o tutor ---");
        controller.listarAnimaisDoTutor(tutor.getId());

        System.out.println("\n--- 4. Registrando consulta (movimento) ---");
        Consulta consulta = new Consulta(animal.getId(), LocalDate.now(), "Check-up anual", new BigDecimal("150.00"));
        controller.registrarConsulta(consulta);

        System.out.println("\n--- 5. Histórico de consultas do animal ---");
        controller.listarConsultasDoAnimal(animal.getId());

        System.out.println("\n--- 6. Tentativa com valor negativo (deve falhar) ---");
        Consulta consultaInvalida = new Consulta(animal.getId(), LocalDate.now(), "Vacina", new BigDecimal("-50.00"));
        controller.registrarConsulta(consultaInvalida);

        System.out.println("\n=== FIM DA SIMULAÇÃO ===");
    }
}
