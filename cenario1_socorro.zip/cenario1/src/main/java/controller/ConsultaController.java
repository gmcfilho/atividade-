package controller;

import model.Animal;
import model.Consulta;
import model.Tutor;
import service.AnimalService;
import service.ConsultaService;
import service.TutorService;

import java.sql.SQLException;
import java.util.List;

public class ConsultaController {

    private final ConsultaService consultaService;
    private final TutorService tutorService;
    private final AnimalService animalService;

    public ConsultaController(ConsultaService consultaService, TutorService tutorService, AnimalService animalService) {
        this.consultaService = consultaService;
        this.tutorService = tutorService;
        this.animalService = animalService;
    }

    public void registrarConsulta(Consulta consulta) {
        try {
            Consulta salva = consultaService.registrar(consulta);
            System.out.println("[SUCESSO] Consulta registrada: " + salva);
        } catch (IllegalArgumentException e) {
            System.out.println("[ERRO DE NEGÓCIO] " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
        }
    }

    public void listarConsultasDoAnimal(Long idAnimal) {
        try {
            List<Consulta> consultas = consultaService.listarPorAnimal(idAnimal);
            System.out.println("[HISTÓRICO] Consultas do animal id=" + idAnimal + ":");
            consultas.forEach(c -> System.out.println("  " + c));
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
        }
    }

    public void listarAnimaisDoTutor(Long idTutor) {
        try {
            List<Animal> animais = tutorService.listarAnimaisDoTutor(idTutor);
            System.out.println("[ANIMAIS] do tutor id=" + idTutor + ":");
            animais.forEach(a -> System.out.println("  " + a));
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
        }
    }

    public Tutor cadastrarTutor(Tutor tutor) {
        try {
            Tutor salvo = tutorService.cadastrar(tutor);
            System.out.println("[SUCESSO] Tutor cadastrado: " + salvo);
            return salvo;
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
            return null;
        }
    }

    public Animal cadastrarAnimal(Animal animal) {
        try {
            Animal salvo = animalService.cadastrar(animal);
            System.out.println("[SUCESSO] Animal cadastrado: " + salvo);
            return salvo;
        } catch (IllegalArgumentException e) {
            System.out.println("[ERRO DE NEGÓCIO] " + e.getMessage());
            return null;
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
            return null;
        }
    }
}
