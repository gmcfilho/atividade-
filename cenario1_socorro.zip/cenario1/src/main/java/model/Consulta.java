package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Consulta {
    private Long id;
    private Long idAnimal;
    private LocalDate data;
    private String motivo;
    private BigDecimal valor;

    public Consulta() {}

    public Consulta(Long id, Long idAnimal, LocalDate data, String motivo, BigDecimal valor) {
        this.id = id;
        this.idAnimal = idAnimal;
        this.data = data;
        this.motivo = motivo;
        this.valor = valor;
    }

    public Consulta(Long idAnimal, LocalDate data, String motivo, BigDecimal valor) {
        this.idAnimal = idAnimal;
        this.data = data;
        this.motivo = motivo;
        this.valor = valor;
    }

    public Long getId() { return id; }
    public Long getIdAnimal() { return idAnimal; }
    public LocalDate getData() { return data; }
    public String getMotivo() { return motivo; }
    public BigDecimal getValor() { return valor; }
    public void setId(Long id) { this.id = id; }
    public void setIdAnimal(Long idAnimal) { this.idAnimal = idAnimal; }
    public void setData(LocalDate data) { this.data = data; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
    public void setValor(BigDecimal valor) { this.valor = valor; }

    @Override
    public String toString() {
        return "Consulta{id=" + id + ", idAnimal=" + idAnimal + ", data=" + data + ", motivo='" + motivo + "', valor=" + valor + "}";
    }
}
