package service;

import model.Animal;
import model.Consulta;
import repository.AnimalRepository;
import repository.ConsultaRepository;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class ConsultaService {

    private final ConsultaRepository consultaRepository;
    private final AnimalRepository animalRepository;

    public ConsultaService(ConsultaRepository consultaRepository, AnimalRepository animalRepository) {
        this.consultaRepository = consultaRepository;
        this.animalRepository = animalRepository;
    }

    public Consulta registrar(Consulta consulta) throws SQLException {
        Optional<Animal> animal = animalRepository.buscarPorId(consulta.getIdAnimal());
        if (animal.isEmpty()) {
            throw new IllegalArgumentException("Animal com id " + consulta.getIdAnimal() + " não encontrado.");
        }

        if (consulta.getValor().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("O valor da consulta não pode ser negativo.");
        }

        return consultaRepository.salvar(consulta);
    }

    public List<Consulta> listarPorAnimal(Long idAnimal) throws SQLException {
        return consultaRepository.listarPorAnimal(idAnimal);
    }

    public List<Consulta> listarTodas() throws SQLException {
        return consultaRepository.listarTodas();
    }
}
