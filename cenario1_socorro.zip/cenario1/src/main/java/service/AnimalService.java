package service;

import model.Animal;
import model.Tutor;
import repository.AnimalRepository;
import repository.TutorRepository;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class AnimalService {

    private final AnimalRepository animalRepository;
    private final TutorRepository tutorRepository;

    public AnimalService(AnimalRepository animalRepository, TutorRepository tutorRepository) {
        this.animalRepository = animalRepository;
        this.tutorRepository = tutorRepository;
    }

    public Animal cadastrar(Animal animal) throws SQLException {
        Optional<Tutor> tutor = tutorRepository.buscarPorId(animal.getIdTutor());
        if (tutor.isEmpty()) {
            throw new IllegalArgumentException("Tutor com id " + animal.getIdTutor() + " não encontrado.");
        }
        return animalRepository.salvar(animal);
    }

    public List<Animal> listarTodos() throws SQLException {
        return animalRepository.listarTodos();
    }
}
