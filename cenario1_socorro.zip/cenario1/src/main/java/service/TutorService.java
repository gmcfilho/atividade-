package service;

import model.Animal;
import model.Tutor;
import repository.AnimalRepository;
import repository.TutorRepository;

import java.sql.SQLException;
import java.util.List;

public class TutorService {

    private final TutorRepository tutorRepository;
    private final AnimalRepository animalRepository;

    public TutorService(TutorRepository tutorRepository, AnimalRepository animalRepository) {
        this.tutorRepository = tutorRepository;
        this.animalRepository = animalRepository;
    }

    public Tutor cadastrar(Tutor tutor) throws SQLException {
        return tutorRepository.salvar(tutor);
    }

    public List<Animal> listarAnimaisDoTutor(Long idTutor) throws SQLException {
        return animalRepository.listarPorTutor(idTutor);
    }

    public List<Tutor> listarTodos() throws SQLException {
        return tutorRepository.listarTodos();
    }
}
