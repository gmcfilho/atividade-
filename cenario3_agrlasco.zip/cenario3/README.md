# Cenário 3 – Sistema de Escola de Cursos Livres

## Tabelas Identificadas

### aluno
```sql
CREATE TABLE aluno (
    id       SERIAL PRIMARY KEY,
    nome     VARCHAR(100) NOT NULL,
    email    VARCHAR(150) NOT NULL UNIQUE,
    telefone VARCHAR(20)  NOT NULL
);
```

### curso
```sql
CREATE TABLE curso (
    id                  SERIAL PRIMARY KEY,
    nome                VARCHAR(100) NOT NULL,
    descricao           TEXT         NOT NULL,
    carga_horaria       INTEGER      NOT NULL,
    vagas_totais        INTEGER      NOT NULL,
    vagas_disponiveis   INTEGER      NOT NULL
);
```

### matricula
```sql
CREATE TABLE matricula (
    id              SERIAL PRIMARY KEY,
    id_aluno        INTEGER        NOT NULL REFERENCES aluno(id),
    id_curso        INTEGER        NOT NULL REFERENCES curso(id),
    data_matricula  DATE           NOT NULL,
    valor           NUMERIC(10, 2) NOT NULL,
    UNIQUE (id_aluno, id_curso)
);
```

---

## Regras de Negócio

| # | Regra |
|---|-------|
| RN01 | Não é permitido matricular um aluno que não esteja cadastrado no sistema. |
| RN02 | Não é permitido matricular em um curso que não esteja cadastrado no sistema. |
| RN03 | Não é possível realizar matrícula em curso sem vagas disponíveis. |
| RN04 | O mesmo aluno não pode ser matriculado duas vezes no mesmo curso. |
| RN05 | O valor pago na matrícula não pode ser negativo. |
| RN06 | Ao realizar uma matrícula, o número de vagas disponíveis do curso deve ser decrementado. |
| RN07 | É possível consultar todos os alunos matriculados em um curso. |
| RN08 | É possível consultar todos os cursos em que um aluno está matriculado. |

---

## Fluxo simulado na Main

`Aluno → Curso → Matrícula`

1. Cadastra dois alunos
2. Cadastra um curso com apenas 1 vaga
3. Matricula o aluno1 com sucesso
4. Lista alunos do curso
5. Tenta matricular aluno1 novamente (demonstra RN04 — matrícula duplicada)
6. Tenta matricular aluno2 (demonstra RN03 — sem vagas)
7. Lista os cursos do aluno1
8. Tenta matrícula com valor negativo (demonstra RN05)
