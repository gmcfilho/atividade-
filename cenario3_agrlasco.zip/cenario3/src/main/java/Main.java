import controller.EscolaController;
import model.Aluno;
import model.Curso;
import model.Matricula;
import repository.AlunoRepository;
import repository.CursoRepository;
import repository.MatriculaRepository;
import service.MatriculaService;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {
        AlunoRepository alunoRepository = new AlunoRepository();
        CursoRepository cursoRepository = new CursoRepository();
        MatriculaRepository matriculaRepository = new MatriculaRepository();

        MatriculaService matriculaService = new MatriculaService(matriculaRepository, alunoRepository, cursoRepository);
        EscolaController controller = new EscolaController(matriculaService, alunoRepository, cursoRepository);

        System.out.println("=== SIMULAÇÃO: ESCOLA DE CURSOS LIVRES ===\n");

        System.out.println("--- 1. Cadastrando alunos ---");
        Aluno aluno1 = controller.cadastrarAluno(new Aluno("Ana Costa", "ana@email.com", "44999770003"));
        Aluno aluno2 = controller.cadastrarAluno(new Aluno("Carlos Lima", "carlos@email.com", "44999770004"));

        if (aluno1 == null || aluno2 == null) return;

        System.out.println("\n--- 2. Cadastrando curso com 1 vaga ---");
        Curso curso = controller.cadastrarCurso(new Curso("Java do Zero", "Aprenda Java do básico ao avançado", 40, 1));

        if (curso == null) return;

        System.out.println("\n--- 3. Matriculando aluno1 (deve funcionar) ---");
        Matricula m1 = controller.realizarMatricula(
            new Matricula(aluno1.getId(), curso.getId(), LocalDate.now(), new BigDecimal("499.90"))
        );

        System.out.println("\n--- 4. Alunos matriculados no curso ---");
        controller.listarAlunosDoCurso(curso.getId());

        System.out.println("\n--- 5. Tentativa de matrícula duplicada (deve falhar) ---");
        controller.realizarMatricula(
            new Matricula(aluno1.getId(), curso.getId(), LocalDate.now(), new BigDecimal("499.90"))
        );

        System.out.println("\n--- 6. Tentativa sem vagas disponíveis (deve falhar) ---");
        controller.realizarMatricula(
            new Matricula(aluno2.getId(), curso.getId(), LocalDate.now(), new BigDecimal("499.90"))
        );

        System.out.println("\n--- 7. Cursos em que aluno1 está matriculado ---");
        controller.listarCursosDoAluno(aluno1.getId());

        System.out.println("\n--- 8. Tentativa com valor negativo (deve falhar) ---");
        Curso curso2 = controller.cadastrarCurso(new Curso("Python Básico", "Introdução ao Python", 20, 10));
        if (curso2 != null) {
            controller.realizarMatricula(
                new Matricula(aluno1.getId(), curso2.getId(), LocalDate.now(), new BigDecimal("-100.00"))
            );
        }

        System.out.println("\n=== FIM DA SIMULAÇÃO ===");
    }
}
