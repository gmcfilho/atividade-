package service;

import model.Aluno;
import model.Curso;
import model.Matricula;
import repository.AlunoRepository;
import repository.CursoRepository;
import repository.MatriculaRepository;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class MatriculaService {

    private final MatriculaRepository matriculaRepository;
    private final AlunoRepository alunoRepository;
    private final CursoRepository cursoRepository;

    public MatriculaService(MatriculaRepository matriculaRepository,
                             AlunoRepository alunoRepository,
                             CursoRepository cursoRepository) {
        this.matriculaRepository = matriculaRepository;
        this.alunoRepository = alunoRepository;
        this.cursoRepository = cursoRepository;
    }

    public Matricula matricular(Matricula matricula) throws SQLException {
        Optional<Aluno> aluno = alunoRepository.buscarPorId(matricula.getIdAluno());
        if (aluno.isEmpty()) {
            throw new IllegalArgumentException("Aluno com id " + matricula.getIdAluno() + " não encontrado.");
        }

        Optional<Curso> cursoOpt = cursoRepository.buscarPorId(matricula.getIdCurso());
        if (cursoOpt.isEmpty()) {
            throw new IllegalArgumentException("Curso com id " + matricula.getIdCurso() + " não encontrado.");
        }

        Curso curso = cursoOpt.get();

        if (curso.getVagasDisponiveis() <= 0) {
            throw new IllegalStateException("O curso '" + curso.getNome() + "' não possui vagas disponíveis.");
        }

        if (matriculaRepository.existeMatricula(matricula.getIdAluno(), matricula.getIdCurso())) {
            throw new IllegalStateException("Aluno já está matriculado no curso '" + curso.getNome() + "'.");
        }

        if (matricula.getValor().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("O valor da matrícula não pode ser negativo.");
        }

        curso.setVagasDisponiveis(curso.getVagasDisponiveis() - 1);
        cursoRepository.atualizar(curso);

        return matriculaRepository.salvar(matricula);
    }

    public List<Matricula> listarPorCurso(Long idCurso) throws SQLException {
        return matriculaRepository.listarPorCurso(idCurso);
    }

    public List<Matricula> listarPorAluno(Long idAluno) throws SQLException {
        return matriculaRepository.listarPorAluno(idAluno);
    }
}
