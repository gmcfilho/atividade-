package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Matricula {
    private Long id;
    private Long idAluno;
    private Long idCurso;
    private LocalDate dataMatricula;
    private BigDecimal valor;

    public Matricula() {}

    public Matricula(Long id, Long idAluno, Long idCurso, LocalDate dataMatricula, BigDecimal valor) {
        this.id = id;
        this.idAluno = idAluno;
        this.idCurso = idCurso;
        this.dataMatricula = dataMatricula;
        this.valor = valor;
    }

    public Matricula(Long idAluno, Long idCurso, LocalDate dataMatricula, BigDecimal valor) {
        this.idAluno = idAluno;
        this.idCurso = idCurso;
        this.dataMatricula = dataMatricula;
        this.valor = valor;
    }

    public Long getId() { return id; }
    public Long getIdAluno() { return idAluno; }
    public Long getIdCurso() { return idCurso; }
    public LocalDate getDataMatricula() { return dataMatricula; }
    public BigDecimal getValor() { return valor; }
    public void setId(Long id) { this.id = id; }
    public void setIdAluno(Long idAluno) { this.idAluno = idAluno; }
    public void setIdCurso(Long idCurso) { this.idCurso = idCurso; }
    public void setDataMatricula(LocalDate dataMatricula) { this.dataMatricula = dataMatricula; }
    public void setValor(BigDecimal valor) { this.valor = valor; }

    @Override
    public String toString() {
        return "Matricula{id=" + id + ", idAluno=" + idAluno + ", idCurso=" + idCurso + ", data=" + dataMatricula + ", valor=" + valor + "}";
    }
}
