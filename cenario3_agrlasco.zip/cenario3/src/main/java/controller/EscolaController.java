package controller;

import model.Aluno;
import model.Curso;
import model.Matricula;
import repository.AlunoRepository;
import repository.CursoRepository;
import service.MatriculaService;

import java.sql.SQLException;
import java.util.List;

public class EscolaController {

    private final MatriculaService matriculaService;
    private final AlunoRepository alunoRepository;
    private final CursoRepository cursoRepository;

    public EscolaController(MatriculaService matriculaService,
                             AlunoRepository alunoRepository,
                             CursoRepository cursoRepository) {
        this.matriculaService = matriculaService;
        this.alunoRepository = alunoRepository;
        this.cursoRepository = cursoRepository;
    }

    public Aluno cadastrarAluno(Aluno aluno) {
        try {
            Aluno salvo = alunoRepository.salvar(aluno);
            System.out.println("[SUCESSO] Aluno cadastrado: " + salvo);
            return salvo;
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
            return null;
        }
    }

    public Curso cadastrarCurso(Curso curso) {
        try {
            Curso salvo = cursoRepository.salvar(curso);
            System.out.println("[SUCESSO] Curso cadastrado: " + salvo);
            return salvo;
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
            return null;
        }
    }

    public Matricula realizarMatricula(Matricula matricula) {
        try {
            Matricula salva = matriculaService.matricular(matricula);
            System.out.println("[SUCESSO] Matrícula realizada: " + salva);
            return salva;
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("[ERRO DE NEGÓCIO] " + e.getMessage());
            return null;
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
            return null;
        }
    }

    public void listarAlunosDoCurso(Long idCurso) {
        try {
            List<Matricula> matriculas = matriculaService.listarPorCurso(idCurso);
            System.out.println("[ALUNOS] matriculados no curso id=" + idCurso + ":");
            matriculas.forEach(m -> System.out.println("  idAluno=" + m.getIdAluno() + " | data=" + m.getDataMatricula()));
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
        }
    }

    public void listarCursosDoAluno(Long idAluno) {
        try {
            List<Matricula> matriculas = matriculaService.listarPorAluno(idAluno);
            System.out.println("[CURSOS] do aluno id=" + idAluno + ":");
            matriculas.forEach(m -> System.out.println("  idCurso=" + m.getIdCurso() + " | data=" + m.getDataMatricula()));
        } catch (SQLException e) {
            System.out.println("[ERRO DE BANCO] " + e.getMessage());
        }
    }
}
